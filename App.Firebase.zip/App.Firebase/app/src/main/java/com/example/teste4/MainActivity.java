package com.example.teste4;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    //Criamos componestes onde vamos atribuir nosso elementos do XML
    private EditText edtnome;
    private ListView lvLista;
    private String ID;

    //Objetos necessarios para conexão com Banco Realtime
    FirebaseDatabase myfirebaseDatabase; //Instancia para acessar o banco
    DatabaseReference mydatabaseReference; //Referencia para manusear o banco


    private List<Nome> nomeList = new ArrayList<Nome>(); //Componente de lista para guardas os nomes do banco de lista-los
    private Adapter_Nome arrayAdapter; //Componente adapter que criamos

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Class para organizer o codigo
        iniciarComponentes();
        iniciarFirebase();
        ListarNome();
    }

    private void ListarNome() {
        //Pega a referencia da "Tabela" Nome para puxar os dados, organiza em ordem alfabetica por nome
        mydatabaseReference.child("Nome").orderByChild("nome").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //Limpa nossa lista que fica em constante atualização
                nomeList.clear();
                //For para passar todos os dados para nossa lista
                for (DataSnapshot data: dataSnapshot.getChildren()) {
                    //Pega todos os dado do nosso model NOME e passa para lista
                    Nome nome = data.getValue(Nome.class);
                    //adiciona os elementos a lista
                    nomeList.add(nome);
                }

                //Chama o nosso adapter criado e passa as informações para ele o listar
                arrayAdapter = new Adapter_Nome(getApplicationContext(), nomeList);
                //passa as informações listadas para o nosso objeto ListView em tela
                lvLista.setAdapter(arrayAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void iniciarFirebase() {
        FirebaseApp.initializeApp(this); //Inicia nossa aplicação para acessar os serviços Firebase
        myfirebaseDatabase = FirebaseDatabase.getInstance(); //Pegar instancia URL para ter acesso ao banco
        mydatabaseReference = myfirebaseDatabase.getReference(); //Passa referencia ou caminho da URL do banco
    }

    private void iniciarComponentes() {
        //Chamando os componentes do XML
        edtnome = findViewById(R.id.edtNome);
        lvLista = findViewById(R.id.lvLista);

        //Torna possivel o uso do click na lista lvLista
        lvLista.setOnItemClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //Chama o nosso menu mymenu na nossa aplicação
        getMenuInflater().inflate(R.menu.mymenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //pega o ID do elemento selecionado no menu
        int id = item.getItemId();

        //Inserir um novo elemento no banco
        if (id == R.id.nav_novo) {
            //chama o model que criamos para controlar nosso dados
            Nome mynome = new Nome();
            //Define um numero aleatorio como ID do nome
            mynome.setId(UUID.randomUUID().toString());
            //Define o nome de acordo com o que digitarmos
            mynome.setNome(edtnome.getText().toString());
            //Chama a URL do banco, adicionando o campo Nome, dentro dele vai as informações
            mydatabaseReference.child("Nome").child(mynome.getId()).setValue(mynome);
            //Limpa nosso componente edtNome em tela
            limparComponentes();
        }

        //Deletar as informações selecionadas
        else if (id == R.id.nav_deletar) {

            //se a variavel não estiver vazia ele apaga o nome selecionado
            if (ID != null) {
                //chama o model que criamos para controlar nosso dados
                Nome mynome = new Nome();
                //pega o ID do elemento que selecionado da lista
                mynome.setId(ID);
                //Chama a URL do banco dentro de objeto Nome e deleta o elemento do qual o ID seja igual ao objeto selecionado em tela
                mydatabaseReference.child("Nome").child(mynome.getId()).removeValue();
            }
        }

        return true;
    }

    private void limparComponentes() {
        //Limpa do campo de texto em tela
        edtnome.setText("");
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        //Exibe mensagem na tela
        Toast.makeText(this, nomeList.get(position).getNome() + " selecionado", Toast.LENGTH_SHORT).show();

        //Limpa a variavel ID
        ID = null;
        //Passa o ID do nome selecionado em tela
        ID = nomeList.get(position).getId();
    }
}