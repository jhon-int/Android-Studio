package com.example.teste4;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class Adapter_Nome extends BaseAdapter {

    private Context context;
    private List<Nome> nomeList;

    public Adapter_Nome(Context context, List<Nome> nomeList) {
        this.context = context;
        this.nomeList = nomeList;
    }

    @Override
    public int getCount() {
        return nomeList.size();
    }

    @Override
    public Object getItem(int position) {
        return nomeList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //pega nosso elemento visual do XML
        View v = View.inflate(context, R.layout.adapter_nome, null);

        //chama nosso elemento de texto em tela
        TextView txtNome = (TextView) v.findViewById(R.id.txtNome);
        //define um texto para ser exibido no objeto
        txtNome.setText(nomeList.get(position).getNome());

        return v;
    }
}
